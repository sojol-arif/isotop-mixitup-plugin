$(document).ready(function(){
	$('#nav').slicknav();
	 $("#responsive-videos").fitVids();
	 
	 //installize MixItUp;
	 $('.portfolio-item').mixItUp();
});